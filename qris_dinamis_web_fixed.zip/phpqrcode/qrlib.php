<?php
// Include PHP QR Code Library
// Download full version from http://phpqrcode.sourceforge.net
function QRcode::png($text, $filename, $level, $size, $margin) {
    echo 'QRcode::png placeholder. Download the real library.';
}
?>